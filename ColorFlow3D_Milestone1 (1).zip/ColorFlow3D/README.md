# ColorFlow 3D: Bus Jam Escape — Milestone 1

A Unity/C# portrait puzzle-game source project. The first level uses original procedural low-poly vehicles and a small toy terminal assembled from Unity primitives; there are no external art assets or paid dependencies.

## Verified scope and limitations

This project folder, level data, runtime scripts, and a Python level validator have been created in the Manus sandbox. The sandbox used for this task has **no Unity Editor/Hub, C# compiler, Java/JDK, Android SDK/NDK, or `adb`**. Therefore Unity compilation, Play Mode, Android device testing, APK/AAB generation, and AdMob integration have **not** been run or verified. The source is a Unity project starter that must be opened and built on a machine with the listed Unity components. Do not treat the prototype as release-ready.

The prototype includes one six-by-six level; slide movement on each vehicle's axis; cell collision checks; one color-matched bus pickup/exit; passengers and capacity; undo; restart; pause/resume; a short hint; move count; a completion reward; local PlayerPrefs storage; sound/haptics toggles; and a bounded solvability check for the included level. Cars are traffic obstacles and do not need to exit. Reward coins are local-only. Level 2 and a level-selection screen are not included. AdManager is intentionally a no-op until a real AdMob SDK, test unit IDs, and consent flow are set up.

## Open and run in Unity

1. Install Unity Hub and the latest patch in the **Unity 6.3 LTS** editor line. During installation, include **Android Build Support**, **Android SDK & NDK Tools**, and **OpenJDK** if Android builds are needed. The sandbox cannot install or run these components for you.
2. In Unity Hub, choose **Add project from disk** and select this folder (the one containing `Assets`, `Packages`, and `ProjectSettings`). Let Unity import scripts and the Test Framework package.
3. In the Editor, run **ColorFlow → Setup → Create Main Scene & Android Settings** once. This creates `Assets/Scenes/Main.unity`, adds it to Build Settings, and configures portrait orientation, Android API 36 target, and ARM64. The application ID is `com.colorflow.busjamescape`; change it before publishing.
4. Open the `Main` scene if it is not already open, then press **Play**. Tap a vehicle and swipe along its lane. Undo, Hint, Restart, and Pause controls are along the bottom.
5. The included solution is: swipe the **Mint Van down by one cell** (toward the near side of the board), then swipe the **Coral Bus right through the exit**. The bus boards the two Coral passengers when it exits.

## Build an APK locally

1. In Unity, open **File → Build Profiles** (or **Build Settings** depending on editor patch), add/select **Android**, and install or switch to Android if prompted.
2. Confirm `Assets/Scenes/Main.unity` is checked in the scene list. In Player Settings, keep **ARM64** enabled and verify the Android target API is **36** or newer as required by the current Google Play deadline. Set a unique package identifier before distribution.
3. Choose **Build** and save the output as an `.apk` for device testing. For Google Play, enable **Build App Bundle** and generate an `.aab`; configure release signing in Unity's Publishing Settings locally. Do not commit signing keys or passwords.
4. Install/test on a real Android phone. The project has not been profiled for frame rate, memory, battery, device aspect ratios, or touch edge cases.

Google Play's target API requirement changes over time. At the time this project was prepared, Google states that new apps and updates submitted from **August 31, 2026** must target Android 16 / API 36 or higher. Verify the latest Play Console requirement immediately before submission.

## Check the included level data

From the project root, run:

```bash
python3 tools/validate_level.py
```

This checks initial vehicle overlaps/bounds and breadth-first searches the one-cell puzzle state space for a valid matching-bus solution. This Python check is separate from Unity compilation and does not prove that the Unity scene builds or runs.

## Project map

- `Assets/Scripts/Core/` — level model/loader/validation, grid, vehicle, collision, game loop, and runtime bootstrap.
- `Assets/Scripts/Systems/` — passenger matching, objectives, local progress/save helpers, audio/haptics, and an inactive ad placeholder.
- `Assets/Scripts/UI/` — runtime-generated portrait UI.
- `Assets/Editor/ColorFlowProjectSetup.cs` — creates the main scene and configures Android project settings.
- `Assets/Resources/Levels/level_01.json` — first data-driven puzzle.
- `tools/validate_level.py` — independent level geometry and solvability validator.

## Current unfinished work / known limitations

- No Unity or Android build has been executed in this environment; C# compile status is unverified.
- Only one playable level is authored. Multi-level progression, daily challenge, cosmetics/terminal builder, production save migration, and a full settings screen remain unfinished.
- Visuals are procedural primitives, not finished custom meshes. Shadows/materials are basic; there are no polished bus boarding/exiting animations, particles, reflections, custom logo/icon, or accessibility pass.
- Undo records each successful swipe as one action. The game has one right-side exit and a single passenger color group in the sample.
- The AdMob class does not display ads. Privacy/consent behavior, real rewarded callbacks, test ad units, interstitial frequency caps, and Play disclosures must be implemented and tested before monetization.
- No signed release bundle, store listing, screenshots, or privacy policy has been produced.

## External references

- Unity's official release support page identifies Unity 6.3 LTS as the current LTS and states support through December 2027: https://unity.com/releases/unity-6/support
- Unity's Android documentation describes API level 36 support in supported Unity 6 releases: https://docs.unity3d.com/6000.0/Documentation/Manual/android-requirements-and-compatibility.html
- Google Play target API requirement: https://developer.android.com/google/play/requirements/target-sdk
