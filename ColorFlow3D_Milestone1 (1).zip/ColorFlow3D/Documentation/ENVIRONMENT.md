# Environment check (2026-10-19)

Checked in the task's Ubuntu 24.04 sandbox.

- Unity Editor / Unity Hub: not found.
- .NET SDK, `csc`, and Mono `mcs`: not found.
- Java `javac`, Gradle, Android SDK environment variables, and `adb`: not found.
- Result: actual Unity C# compilation and Android APK/AAB builds are unavailable here. Project files were authored, but engine execution is not verified.

Unity version choice: Unity 6.3 LTS branch, using lightweight built-in rendering and no URP package. Unity's release support page says Unity 6.3 LTS is supported until December 2027. The target project configuration uses Android API 36 and ARM64; Google Play's published requirement starts August 31, 2026 for new apps and updates.
