using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class LevelData
{
    public int levelId = 1;
    public string title = "First Pickup";
    public int columns = 6;
    public int rows = 6;
    public int exitRow = 2;
    public float cellSize = 1.15f;
    public VehicleDefinition[] vehicles;
    public PassengerGroup[] passengers;
}

[Serializable]
public class VehicleDefinition
{
    public string id;
    public string displayName;
    public int x;
    public int z;
    public int length = 2;
    public bool horizontal = true;
    public bool isBus;
    public string color = "#F37463";
    public int capacity;
}

[Serializable]
public class PassengerGroup
{
    public string color = "#F37463";
    public int count;
    public string label;
}

public static class LevelValidator
{
    public static List<string> Validate(LevelData level)
    {
        var errors = new List<string>();
        if (level == null) { errors.Add("Level data is missing."); return errors; }
        if (level.columns < 2 || level.rows < 2) errors.Add("Board dimensions must be at least 2 by 2.");
        if (level.vehicles == null || level.vehicles.Length == 0) errors.Add("Level needs at least one vehicle.");
        if (level.passengers == null || level.passengers.Length == 0) errors.Add("Level needs a passenger objective.");
        if (level.exitRow < 0 || level.exitRow >= level.rows) errors.Add("Exit row is outside the board.");

        var occupied = new Dictionary<Vector2Int, string>();
        var matchingCapacity = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        if (level.vehicles != null)
        {
            foreach (var v in level.vehicles)
            {
                if (v == null) { errors.Add("A vehicle entry is empty."); continue; }
                if (string.IsNullOrWhiteSpace(v.id)) errors.Add("Every vehicle needs an id.");
                if (v.length < 2) errors.Add($"Vehicle {v.id} must be at least 2 cells long.");
                if (!ColorUtility.TryParseHtmlString(v.color, out _)) errors.Add($"Vehicle {v.id} has an invalid color.");
                if (v.isBus && v.capacity <= 0) errors.Add($"Bus {v.id} must have positive capacity.");
                for (int i = 0; i < Math.Max(0, v.length); i++)
                {
                    var cell = v.horizontal ? new Vector2Int(v.x + i, v.z) : new Vector2Int(v.x, v.z + i);
                    if (cell.x < 0 || cell.x >= level.columns || cell.y < 0 || cell.y >= level.rows)
                    { errors.Add($"Vehicle {v.id} is outside the board."); continue; }
                    if (occupied.TryGetValue(cell, out var other)) errors.Add($"Vehicles {v.id} and {other} overlap at {cell}.");
                    else occupied[cell] = v.id;
                }
                if (v.isBus)
                {
                    var key = v.color ?? "";
                    matchingCapacity[key] = (matchingCapacity.TryGetValue(key, out int old) ? old : 0) + Math.Max(0, v.capacity);
                }
            }
        }
        if (level.passengers != null)
        {
            foreach (var group in level.passengers)
            {
                if (group == null || group.count <= 0) { errors.Add("Passenger groups must have a positive count."); continue; }
                if (!ColorUtility.TryParseHtmlString(group.color, out _)) errors.Add("A passenger group has an invalid color.");
                int capacity = matchingCapacity.TryGetValue(group.color ?? "", out int total) ? total : 0;
                if (capacity < group.count) errors.Add($"Passenger group {group.label} exceeds matching bus capacity.");
            }
        }
        return errors;
    }
}

public class LevelManager
{
    public LevelData Current { get; private set; }

    public LevelData Load(int levelId)
    {
        string resourcePath = $"Levels/level_{levelId:00}";
        var asset = Resources.Load<TextAsset>(resourcePath);
        if (asset == null) throw new InvalidOperationException($"Missing level resource: {resourcePath}.json");
        var parsed = JsonUtility.FromJson<LevelData>(asset.text);
        var errors = LevelValidator.Validate(parsed);
        if (errors.Count > 0) throw new InvalidOperationException("Invalid level: " + string.Join(" | ", errors));
        Current = parsed;
        return Current;
    }
}
