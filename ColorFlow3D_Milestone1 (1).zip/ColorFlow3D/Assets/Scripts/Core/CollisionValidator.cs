using UnityEngine;

public static class CollisionValidator
{
    public static bool TryMoveOne(VehicleController vehicle, int direction, GridSystem grid, PassengerManager passengers, out bool exited)
    {
        exited = false;
        if (vehicle == null || !vehicle.IsOnBoard || (direction != -1 && direction != 1)) return false;
        int nextX = vehicle.GridX + (vehicle.Horizontal ? direction : 0);
        int nextZ = vehicle.GridZ + (vehicle.Horizontal ? 0 : direction);

        bool outRight = vehicle.Horizontal && direction > 0 && nextX + vehicle.Length > grid.Columns;
        if (outRight)
        {
            if (!vehicle.IsBus || vehicle.GridZ != grid.ExitRow || nextX != grid.Columns - vehicle.Length + 1) return false;
            for (int i = 0; i < vehicle.Length; i++)
            {
                int x = nextX + i;
                if (grid.IsInside(x, nextZ) && !grid.IsFree(x, nextZ, vehicle)) return false;
            }
            if (passengers == null || !passengers.TryBoard(vehicle)) return false;
            vehicle.SetOnBoard(false);
            grid.RebuildOccupancy(GameManager.Instance.Vehicles);
            exited = true;
            return true;
        }

        for (int i = 0; i < vehicle.Length; i++)
        {
            int x = vehicle.Horizontal ? nextX + i : nextX;
            int z = vehicle.Horizontal ? nextZ : nextZ + i;
            if (!grid.IsFree(x, z, vehicle)) return false;
        }
        vehicle.SetGridPosition(nextX, nextZ);
        grid.RebuildOccupancy(GameManager.Instance.Vehicles);
        return true;
    }
}
