using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }
    public IReadOnlyList<VehicleController> Vehicles => vehicles;
    public int Moves { get; private set; }
    public int CurrentLevel => levelData != null ? levelData.levelId : 1;
    public VehicleController SelectedVehicle => selected;
    public PassengerManager Passengers => passengers;
    public GridSystem Grid => grid;
    public bool IsPaused { get; private set; }
    public bool IsComplete { get; private set; }

    private readonly List<VehicleController> vehicles = new List<VehicleController>();
    private readonly Stack<GameSnapshot> history = new Stack<GameSnapshot>();
    private LevelData levelData;
    private GridSystem grid;
    private PassengerManager passengers;
    private ObjectiveManager objectives;
    private UIManager ui;
    private AudioManager audioManager;
    private Camera gameCamera;
    private VehicleController selected;
    private Vector3 dragStartWorld;
    private Vector2 dragStartScreen;
    private bool pointerActive;
    private bool completedOnce;

    private sealed class GameSnapshot
    {
        public int[] x;
        public int[] z;
        public bool[] active;
        public int[] passengerCounts;
        public int moves;
    }

    private void Awake() { Instance = this; }

    public void Initialize(LevelData data, GridSystem board, UIManager interfaceManager, AudioManager soundManager, Camera camera)
    {
        levelData = data;
        grid = board;
        ui = interfaceManager;
        audioManager = soundManager;
        gameCamera = camera;
        objectives = new ObjectiveManager();
        objectives.Completed += HandleComplete;
        CreateVehicles();
        passengers = new PassengerManager(levelData.passengers);
        passengers.Changed += RefreshUI;
        ui.Refresh(this);
    }

    private void CreateVehicles()
    {
        foreach (var old in vehicles) if (old != null) Destroy(old.gameObject);
        vehicles.Clear();
        foreach (var definition in levelData.vehicles)
        {
            var go = new GameObject(definition.displayName);
            var vehicle = go.AddComponent<VehicleController>();
            vehicle.Initialize(definition, grid);
            vehicles.Add(vehicle);
        }
        grid.RebuildOccupancy(vehicles);
    }

    private void Update()
    {
        if (IsPaused || IsComplete) return;
        if (Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0);
            if (touch.phase == TouchPhase.Began) BeginPointer(touch.position, touch.fingerId);
            else if (touch.phase == TouchPhase.Ended || touch.phase == TouchPhase.Canceled) EndPointer(touch.position);
        }
        else
        {
            if (Input.GetMouseButtonDown(0)) BeginPointer(Input.mousePosition, -1);
            if (Input.GetMouseButtonUp(0)) EndPointer(Input.mousePosition);
        }
    }

    private void BeginPointer(Vector2 screen, int pointerId)
    {
        pointerActive = false;
        if (EventSystem.current != null && EventSystem.current.IsPointerOverGameObject(pointerId)) return;
        if (gameCamera == null) return;
        Ray ray = gameCamera.ScreenPointToRay(screen);
        if (!Physics.Raycast(ray, out var hit, 200f)) return;
        var vehicle = hit.collider.GetComponentInParent<VehicleController>();
        if (vehicle == null || !vehicle.IsOnBoard) return;
        Select(vehicle);
        if (TryGetBoardPoint(screen, out dragStartWorld))
        {
            dragStartScreen = screen;
            pointerActive = true;
        }
    }

    private void EndPointer(Vector2 screen)
    {
        if (!pointerActive || selected == null) return;
        pointerActive = false;
        if (!TryGetBoardPoint(screen, out var endWorld)) return;
        Vector3 delta = endWorld - dragStartWorld;
        float primary = selected.Horizontal ? delta.x : delta.z;
        float secondary = selected.Horizontal ? delta.z : delta.x;
        if (Mathf.Abs(primary) < grid.CellSize * 0.18f || Mathf.Abs(primary) < Mathf.Abs(secondary)) return;
        int direction = primary > 0f ? 1 : -1;
        int steps = Mathf.Clamp(Mathf.RoundToInt(Mathf.Abs(primary) / grid.CellSize), 1, grid.Columns + grid.Rows);
        bool changed = false;
        GameSnapshot beforeSwipe = CaptureSnapshot();
        for (int i = 0; i < steps; i++)
        {
            if (!CollisionValidator.TryMoveOne(selected, direction, grid, passengers, out bool exited)) break;
            if (!changed) history.Push(beforeSwipe);
            changed = true;
            if (exited)
            {
                selected.SetSelected(false);
                selected = null;
                objectives.Evaluate(passengers);
                break;
            }
        }
        if (changed)
        {
            Moves++;
            if (audioManager != null) audioManager.PlayMove();
            ui.Refresh(this);
        }
    }

    private bool TryGetBoardPoint(Vector2 screen, out Vector3 point)
    {
        Ray ray = gameCamera.ScreenPointToRay(screen);
        Plane plane = new Plane(Vector3.up, Vector3.zero);
        if (plane.Raycast(ray, out float distance)) { point = ray.GetPoint(distance); return true; }
        point = default;
        return false;
    }

    public void Select(VehicleController vehicle)
    {
        if (selected == vehicle) return;
        if (selected != null) selected.SetSelected(false);
        selected = vehicle;
        if (selected != null) selected.SetSelected(true);
        RefreshUI();
    }

    private GameSnapshot CaptureSnapshot()
    {
        var snapshot = new GameSnapshot
        {
            x = new int[vehicles.Count], z = new int[vehicles.Count], active = new bool[vehicles.Count],
            passengerCounts = passengers.Capture(), moves = Moves
        };
        for (int i = 0; i < vehicles.Count; i++)
        {
            snapshot.x[i] = vehicles[i].GridX;
            snapshot.z[i] = vehicles[i].GridZ;
            snapshot.active[i] = vehicles[i].IsOnBoard;
        }
        return snapshot;
    }

    public void Undo()
    {
        if (history.Count == 0 || IsComplete) return;
        var snapshot = history.Pop();
        for (int i = 0; i < vehicles.Count; i++)
        {
            vehicles[i].SetOnBoard(snapshot.active[i]);
            if (snapshot.active[i]) vehicles[i].SetGridPosition(snapshot.x[i], snapshot.z[i]);
        }
        grid.RebuildOccupancy(vehicles);
        passengers.Restore(snapshot.passengerCounts);
        Moves = snapshot.moves;
        IsComplete = false;
        completedOnce = false;
        objectives.Reset();
        Select(null);
        ui.HideCompletion();
        ui.Refresh(this);
    }

    public void RestartLevel()
    {
        IsComplete = false;
        IsPaused = false;
        completedOnce = false;
        Moves = 0;
        history.Clear();
        objectives.Reset();
        if (passengers != null) passengers.Changed -= RefreshUI;
        selected = null;
        CreateVehicles();
        passengers = new PassengerManager(levelData.passengers);
        passengers.Changed += RefreshUI;
        Select(null);
        ui.HideCompletion();
        ui.SetPaused(false);
        ui.Refresh(this);
    }

    public void TogglePause()
    {
        if (IsComplete) return;
        IsPaused = !IsPaused;
        ui.SetPaused(IsPaused);
    }

    public void RequestHint()
    {
        string hint = "Match the next passengers with a bus, then clear the path to the right-hand gate.";
        foreach (var bus in vehicles)
        {
            if (!bus.IsOnBoard || !bus.IsBus || bus.GridZ != grid.ExitRow) continue;
            for (int x = bus.GridX + bus.Length; x < grid.Columns; x++)
            {
                var blocker = grid.At(x, bus.GridZ);
                if (blocker != null && blocker != bus)
                {
                    hint = $"Move {blocker.DisplayName} along its lane to open the gate for {bus.DisplayName}.";
                    break;
                }
            }
            break;
        }
        ui.ShowMessage(hint);
    }

    private void HandleComplete()
    {
        if (completedOnce) return;
        completedOnce = true;
        IsComplete = true;
        ProgressionManager.CompleteLevel(CurrentLevel);
        if (audioManager != null) audioManager.PlayWin();
        ui.ShowCompletion(ProgressionManager.CompletionReward);
        ui.Refresh(this);
    }

    private void RefreshUI() { if (ui != null) ui.Refresh(this); }

    private void OnDestroy()
    {
        if (Instance == this) Instance = null;
        if (objectives != null) objectives.Completed -= HandleComplete;
        if (passengers != null) passengers.Changed -= RefreshUI;
    }
}
