using System.Collections.Generic;
using UnityEngine;

public class GridSystem
{
    public int Columns { get; }
    public int Rows { get; }
    public float CellSize { get; }
    public int ExitRow { get; }
    public Vector3 Origin { get; }
    private readonly Dictionary<Vector2Int, VehicleController> occupancy = new Dictionary<Vector2Int, VehicleController>();

    public GridSystem(LevelData level)
    {
        Columns = level.columns;
        Rows = level.rows;
        CellSize = level.cellSize;
        ExitRow = level.exitRow;
        Origin = new Vector3(-Columns * CellSize * 0.5f + CellSize * 0.5f, 0f,
            -Rows * CellSize * 0.5f + CellSize * 0.5f);
    }

    public Vector3 CellToWorld(int x, int z, float y = 0f) => new Vector3(Origin.x + x * CellSize, y, Origin.z + z * CellSize);

    public Vector2Int WorldToCell(Vector3 world)
    {
        return new Vector2Int(Mathf.RoundToInt((world.x - Origin.x) / CellSize), Mathf.RoundToInt((world.z - Origin.z) / CellSize));
    }

    public bool IsInside(int x, int z) => x >= 0 && x < Columns && z >= 0 && z < Rows;
    public VehicleController At(int x, int z) => occupancy.TryGetValue(new Vector2Int(x, z), out var v) ? v : null;

    public void RebuildOccupancy(IEnumerable<VehicleController> vehicles)
    {
        occupancy.Clear();
        foreach (var vehicle in vehicles)
        {
            if (vehicle == null || !vehicle.IsOnBoard) continue;
            foreach (var cell in vehicle.OccupiedCells()) occupancy[cell] = vehicle;
        }
    }

    public bool IsFree(int x, int z, VehicleController ignore = null)
    {
        if (!IsInside(x, z)) return false;
        var other = At(x, z);
        return other == null || other == ignore;
    }

    public bool IsRayClearToRight(int startX, int z, VehicleController ignore = null)
    {
        for (int x = startX; x < Columns; x++)
            if (!IsFree(x, z, ignore)) return false;
        return true;
    }
}
