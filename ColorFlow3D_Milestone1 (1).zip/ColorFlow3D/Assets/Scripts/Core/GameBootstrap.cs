using UnityEngine;

[DefaultExecutionOrder(-1000)]
public class GameBootstrap : MonoBehaviour
{
    private void Start()
    {
        var level = new LevelManager().Load(1);
        var grid = new GridSystem(level);
        Camera camera = EnsureCamera();
        BuildLighting();
        BuildTerminal(level, grid);

        var uiObject = new GameObject("UI Manager");
        var ui = uiObject.AddComponent<UIManager>();
        ui.Initialize();

        var audioObject = new GameObject("Audio Manager");
        var audio = audioObject.AddComponent<AudioManager>();

        var gameObject = new GameObject("Game Manager");
        var game = gameObject.AddComponent<GameManager>();
        game.Initialize(level, grid, ui, audio, camera);
    }

    private static Camera EnsureCamera()
    {
        Camera camera = Camera.main;
        if (camera == null)
        {
            var cameraObject = new GameObject("Main Camera");
            cameraObject.tag = "MainCamera";
            camera = cameraObject.AddComponent<Camera>();
        }
        camera.clearFlags = CameraClearFlags.SolidColor;
        camera.backgroundColor = new Color(0.68f, 0.83f, 0.88f);
        camera.orthographic = true;
        camera.orthographicSize = 8.65f;
        camera.transform.position = new Vector3(0, 13.5f, -9.5f);
        camera.transform.LookAt(new Vector3(0, 0, 0));
        camera.nearClipPlane = 0.1f;
        camera.farClipPlane = 100f;
        return camera;
    }

    private static void BuildLighting()
    {
        RenderSettings.ambientLight = new Color(0.72f, 0.78f, 0.82f);
        var sunObject = new GameObject("Soft Afternoon Sun");
        var light = sunObject.AddComponent<Light>();
        light.type = LightType.Directional;
        light.intensity = 1.05f;
        light.color = new Color(1f, 0.92f, 0.78f);
        light.shadows = LightShadows.Soft;
        sunObject.transform.rotation = Quaternion.Euler(52, -28, 0);
    }

    private static void BuildTerminal(LevelData level, GridSystem grid)
    {
        float width = level.columns * level.cellSize;
        float depth = level.rows * level.cellSize;
        CreateBox("Park lawn", new Vector3(0, -0.46f, 0), new Vector3(26, 0.2f, 26), new Color(0.35f, 0.63f, 0.43f), 0.02f);
        CreateBox("Terminal island", new Vector3(0, -0.18f, 0), new Vector3(width + 0.48f, 0.48f, depth + 0.48f), new Color(0.97f, 0.88f, 0.68f), 0.05f);
        CreateBox("Road bed", new Vector3(0, 0.06f, 0), new Vector3(width + 0.18f, 0.12f, depth + 0.18f), new Color(0.25f, 0.34f, 0.39f), 0.02f);

        var roadA = MakeMaterial(new Color(0.32f, 0.4f, 0.44f));
        var roadB = MakeMaterial(new Color(0.29f, 0.37f, 0.41f));
        for (int z = 0; z < level.rows; z++)
        for (int x = 0; x < level.columns; x++)
        {
            Vector3 p = grid.CellToWorld(x, z, 0.14f);
            var tile = CreateBox($"Road tile {x}-{z}", p, new Vector3(level.cellSize - 0.045f, 0.055f, level.cellSize - 0.045f), ((x + z) & 1) == 0 ? roadA.color : roadB.color, 0f);
            tile.GetComponent<Renderer>().material = ((x + z) & 1) == 0 ? roadA : roadB;
        }

        // Painted stop line and a freestanding gate communicate the only bus exit.
        Vector3 gateCell = grid.CellToWorld(level.columns - 1, level.exitRow, 0.2f);
        CreateBox("Stop line", new Vector3(gateCell.x + level.cellSize * 0.43f, 0.19f, gateCell.z), new Vector3(0.08f, 0.025f, level.cellSize * 0.72f), new Color(1f, 0.83f, 0.38f), 0f);
        float gateX = width * 0.5f + 0.34f;
        CreateBox("Gate post front", new Vector3(gateX, 0.65f, gateCell.z - 0.53f), new Vector3(0.18f, 1.2f, 0.18f), new Color(0.96f, 0.64f, 0.28f), 0.04f);
        CreateBox("Gate post back", new Vector3(gateX, 0.65f, gateCell.z + 0.53f), new Vector3(0.18f, 1.2f, 0.18f), new Color(0.96f, 0.64f, 0.28f), 0.04f);
        CreateBox("Gate sign", new Vector3(gateX, 1.28f, gateCell.z), new Vector3(0.65f, 0.22f, 1.3f), new Color(0.99f, 0.82f, 0.4f), 0.05f);
        CreateBox("Gate sign face", new Vector3(gateX - 0.035f, 1.29f, gateCell.z), new Vector3(0.025f, 0.14f, 0.98f), new Color(0.96f, 0.45f, 0.31f), 0f);

        BuildWaitingPassengers(level, grid);
        BuildDecorations(width, depth);
    }

    private static void BuildWaitingPassengers(LevelData level, GridSystem grid)
    {
        if (level.passengers == null || level.passengers.Length == 0) return;
        Color color = Color.white;
        ColorUtility.TryParseHtmlString(level.passengers[0].color, out color);
        int count = Mathf.Min(level.passengers[0].count, 3);
        float spacing = 0.48f;
        float start = -(count - 1) * spacing * 0.5f;
        for (int i = 0; i < count; i++)
        {
            float x = start + i * spacing;
            Vector3 basePoint = new Vector3(x, 0.17f, -level.rows * level.cellSize * 0.5f - 0.47f);
            CreateCapsule("Waiting passenger body", basePoint + Vector3.up * 0.22f, new Vector3(0.27f, 0.28f, 0.24f), color);
            CreateSphere("Passenger head", basePoint + Vector3.up * 0.53f, new Vector3(0.23f, 0.23f, 0.23f), new Color(0.91f, 0.73f, 0.58f));
        }
    }

    private static void BuildDecorations(float width, float depth)
    {
        // A small terminal facade and trees frame the puzzle without adding gameplay blockers.
        CreateBox("Station kiosk", new Vector3(-width * 0.5f - 1.15f, 0.54f, depth * 0.5f - 0.2f), new Vector3(1.8f, 1.5f, 1.3f), new Color(0.94f, 0.66f, 0.41f), 0.04f);
        CreateBox("Kiosk roof", new Vector3(-width * 0.5f - 1.15f, 1.34f, depth * 0.5f - 0.2f), new Vector3(2f, 0.16f, 1.5f), new Color(0.9f, 0.38f, 0.3f), 0.03f);
        CreateBox("Kiosk window", new Vector3(-width * 0.5f - 1.15f, 0.65f, depth * 0.5f + 0.47f), new Vector3(0.7f, 0.52f, 0.04f), new Color(0.52f, 0.8f, 0.86f), 0f);
        CreateTree(new Vector3(width * 0.5f + 1.05f, 0, depth * 0.5f + 0.2f));
        CreateTree(new Vector3(-width * 0.5f - 1.08f, 0, -depth * 0.5f + 0.1f));
        CreateFlowerBed(new Vector3(width * 0.5f + 1.05f, 0.04f, -depth * 0.5f + 0.25f));
    }

    private static void CreateTree(Vector3 point)
    {
        CreateCylinder("Tree trunk", point + Vector3.up * 0.55f, new Vector3(0.24f, 0.58f, 0.24f), new Color(0.48f, 0.31f, 0.22f));
        CreateSphere("Tree crown", point + Vector3.up * 1.28f, new Vector3(1.15f, 1.1f, 1.05f), new Color(0.29f, 0.65f, 0.43f));
        CreateSphere("Tree crown highlight", point + new Vector3(-0.18f, 1.52f, -0.08f), new Vector3(0.54f, 0.5f, 0.52f), new Color(0.42f, 0.75f, 0.49f));
    }

    private static void CreateFlowerBed(Vector3 point)
    {
        CreateBox("Flower bed", point, new Vector3(1.15f, 0.2f, 0.65f), new Color(0.74f, 0.82f, 0.52f), 0.02f);
        Color[] blooms = { new Color(0.97f, 0.48f, 0.43f), new Color(1f, 0.82f, 0.38f), new Color(0.78f, 0.62f, 0.9f) };
        for (int i = 0; i < blooms.Length; i++) CreateSphere("Flower", point + new Vector3(-0.35f + i * 0.35f, 0.22f, 0), Vector3.one * 0.22f, blooms[i]);
    }

    private static GameObject CreateBox(string name, Vector3 position, Vector3 scale, Color color, float unused)
    {
        var go = GameObject.CreatePrimitive(PrimitiveType.Cube);
        go.name = name; go.transform.position = position; go.transform.localScale = scale;
        RemoveCollider(go);
        go.GetComponent<Renderer>().material = MakeMaterial(color);
        return go;
    }

    private static GameObject CreateCapsule(string name, Vector3 position, Vector3 scale, Color color)
    {
        var go = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        go.name = name; go.transform.position = position; go.transform.localScale = scale;
        RemoveCollider(go); go.GetComponent<Renderer>().material = MakeMaterial(color); return go;
    }

    private static GameObject CreateSphere(string name, Vector3 position, Vector3 scale, Color color)
    {
        var go = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        go.name = name; go.transform.position = position; go.transform.localScale = scale;
        RemoveCollider(go); go.GetComponent<Renderer>().material = MakeMaterial(color); return go;
    }

    private static GameObject CreateCylinder(string name, Vector3 position, Vector3 scale, Color color)
    {
        var go = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        go.name = name; go.transform.position = position; go.transform.localScale = scale;
        RemoveCollider(go); go.GetComponent<Renderer>().material = MakeMaterial(color); return go;
    }

    private static void RemoveCollider(GameObject go)
    {
        var collider = go.GetComponent<Collider>();
        if (collider != null) Object.Destroy(collider);
    }

    private static Material MakeMaterial(Color color)
    {
        Shader shader = Shader.Find("Standard");
        if (shader == null) shader = Shader.Find("Universal Render Pipeline/Lit");
        var material = new Material(shader) { color = color };
        material.SetFloat("_Glossiness", 0.18f);
        return material;
    }
}
