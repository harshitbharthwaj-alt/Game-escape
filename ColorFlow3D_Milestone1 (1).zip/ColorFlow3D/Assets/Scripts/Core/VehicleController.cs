using System.Collections.Generic;
using UnityEngine;

public class VehicleController : MonoBehaviour
{
    public string Id { get; private set; }
    public string DisplayName { get; private set; }
    public bool Horizontal { get; private set; }
    public bool IsBus { get; private set; }
    public bool IsOnBoard { get; private set; } = true;
    public int Length { get; private set; }
    public int Capacity { get; private set; }
    public int GridX { get; private set; }
    public int GridZ { get; private set; }
    public Color VehicleColor { get; private set; }
    private GridSystem grid;
    private Transform artRoot;
    private Renderer[] artRenderers;
    private Color[] originalColors;
    private bool highlighted;
    private bool hasVisualPosition;
    private Vector3 visualTarget;

    private void Update()
    {
        if (!IsOnBoard || !hasVisualPosition) return;
        transform.position = Vector3.MoveTowards(transform.position, visualTarget, Time.deltaTime * 13f);
    }

    public void Initialize(VehicleDefinition definition, GridSystem gridSystem)
    {
        Id = definition.id;
        DisplayName = definition.displayName;
        Horizontal = definition.horizontal;
        IsBus = definition.isBus;
        Length = definition.length;
        Capacity = definition.capacity;
        GridX = definition.x;
        GridZ = definition.z;
        grid = gridSystem;
        if (!ColorUtility.TryParseHtmlString(definition.color, out var parsed)) parsed = new Color(0.95f, 0.4f, 0.32f);
        VehicleColor = parsed;
        BuildModel();
        SetGridPosition(GridX, GridZ);
    }

    public IEnumerable<Vector2Int> OccupiedCells()
    {
        for (int i = 0; i < Length; i++)
            yield return Horizontal ? new Vector2Int(GridX + i, GridZ) : new Vector2Int(GridX, GridZ + i);
    }

    public void SetGridPosition(int x, int z)
    {
        GridX = x;
        GridZ = z;
        if (grid != null && IsOnBoard)
        {
            Vector3 point = Horizontal
                ? (grid.CellToWorld(x, z) + grid.CellToWorld(x + Length - 1, z)) * 0.5f
                : (grid.CellToWorld(x, z) + grid.CellToWorld(x, z + Length - 1)) * 0.5f;
            visualTarget = new Vector3(point.x, 0.36f, point.z);
            if (!hasVisualPosition) transform.position = visualTarget;
            hasVisualPosition = true;
        }
    }

    public void SetOnBoard(bool value)
    {
        IsOnBoard = value;
        if (artRoot != null) artRoot.gameObject.SetActive(value);
        var collider = GetComponent<Collider>();
        if (collider != null) collider.enabled = value;
    }

    public void SetSelected(bool value)
    {
        highlighted = value;
        if (artRenderers == null) return;
        for (int i = 0; i < artRenderers.Length; i++)
        {
            if (artRenderers[i] == null) continue;
            Color c = originalColors[i];
            artRenderers[i].material.color = value ? Color.Lerp(c, Color.white, 0.24f) : c;
        }
    }

    private void BuildModel()
    {
        artRoot = new GameObject("Toy Vehicle Art").transform;
        artRoot.SetParent(transform, false);
        float size = grid.CellSize;
        float along = size * Length - 0.12f;
        float across = size * 0.76f;
        float height = IsBus ? 0.48f : 0.39f;
        Vector3 bodySize = Horizontal ? new Vector3(along, height, across) : new Vector3(across, height, along);
        AddBox("Rounded body", new Vector3(0, 0.05f, 0), bodySize, VehicleColor, 0.10f);
        float roofAlong = along * (IsBus ? 0.67f : 0.56f);
        Vector3 roofSize = Horizontal ? new Vector3(roofAlong, height * 0.58f, across * 0.79f) : new Vector3(across * 0.79f, height * 0.58f, roofAlong);
        AddBox("Cabin", new Vector3(0, height * 0.58f, 0), roofSize, Color.Lerp(VehicleColor, Color.white, 0.22f), 0.07f);
        Color glass = new Color(0.48f, 0.78f, 0.86f);
        int windowCount = IsBus ? Length : 2;
        for (int i = 0; i < windowCount; i++)
        {
            float offset = (i - (windowCount - 1) * 0.5f) * (roofAlong / Mathf.Max(1, windowCount));
            Vector3 windowSize = Horizontal ? new Vector3(roofAlong / (windowCount + 0.55f), 0.15f, across * 0.82f) : new Vector3(across * 0.82f, 0.15f, roofAlong / (windowCount + 0.55f));
            Vector3 local = Horizontal ? new Vector3(offset, height * 0.71f, 0) : new Vector3(0, height * 0.71f, offset);
            AddBox("Blue window", local, windowSize, glass, 0.02f);
        }
        AddBox("Roof badge", new Vector3(0, height * 1.02f, 0), Horizontal ? new Vector3(0.25f, 0.06f, 0.24f) : new Vector3(0.24f, 0.06f, 0.25f), IsBus ? new Color(1f, 0.88f, 0.42f) : Color.Lerp(VehicleColor, Color.black, 0.1f), 0.03f);
        float wheelOffset = Mathf.Min(along * 0.36f, (Length - 1) * size * 0.42f);
        for (int end = -1; end <= 1; end += 2)
        for (int side = -1; side <= 1; side += 2)
        {
            Vector3 p = Horizontal ? new Vector3(end * wheelOffset, -0.11f, side * across * 0.47f) : new Vector3(side * across * 0.47f, -0.11f, end * wheelOffset);
            AddWheel(p);
        }
        var box = gameObject.AddComponent<BoxCollider>();
        box.size = new Vector3(bodySize.x, 0.9f, bodySize.z);
        var renderers = artRoot.GetComponentsInChildren<Renderer>();
        var filtered = new List<Renderer>();
        foreach (var renderer in renderers) if (renderer != null) filtered.Add(renderer);
        artRenderers = filtered.ToArray();
        originalColors = new Color[artRenderers.Length];
        for (int i = 0; i < artRenderers.Length; i++) originalColors[i] = artRenderers[i].material.color;
    }

    private void AddWheel(Vector3 position)
    {
        var wheel = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        wheel.name = "Rubber wheel";
        wheel.transform.SetParent(artRoot, false);
        wheel.transform.localPosition = position;
        wheel.transform.localScale = new Vector3(0.16f, 0.075f, 0.16f);
        wheel.transform.localRotation = Quaternion.Euler(90, 0, 0);
        var col = wheel.GetComponent<Collider>();
        if (col != null) Destroy(col);
        wheel.GetComponent<Renderer>().material = MakeMaterial(new Color(0.12f, 0.15f, 0.19f));
    }

    private void AddBox(string label, Vector3 localPosition, Vector3 scale, Color color, float roundness)
    {
        var piece = GameObject.CreatePrimitive(PrimitiveType.Cube);
        piece.name = label;
        piece.transform.SetParent(artRoot, false);
        piece.transform.localPosition = localPosition;
        piece.transform.localScale = scale;
        var col = piece.GetComponent<Collider>();
        if (col != null) Destroy(col);
        piece.GetComponent<Renderer>().material = MakeMaterial(color);
    }

    private static Material MakeMaterial(Color color)
    {
        Shader shader = Shader.Find("Standard");
        if (shader == null) shader = Shader.Find("Universal Render Pipeline/Lit");
        var material = new Material(shader) { color = color };
        material.SetFloat("_Glossiness", 0.22f);
        return material;
    }
}
