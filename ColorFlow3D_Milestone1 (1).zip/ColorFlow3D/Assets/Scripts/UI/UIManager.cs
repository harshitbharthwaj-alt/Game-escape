using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;

public class UIManager : MonoBehaviour
{
    private Canvas canvas;
    private Text levelText;
    private Text movesText;
    private Text passengerText;
    private Text selectedText;
    private Text coinsText;
    private Text toastText;
    private Image passengerSwatch;
    private GameObject pausePanel;
    private GameObject winPanel;
    private Text soundToggleText;
    private Text hapticsToggleText;

    public void Initialize()
    {
        var canvasObject = new GameObject("ColorFlow UI Canvas");
        canvasObject.transform.SetParent(transform, false);
        canvas = canvasObject.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvas.pixelPerfect = true;
        var scaler = canvasObject.AddComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1080, 1920);
        scaler.matchWidthOrHeight = 0.5f;
        canvasObject.AddComponent<GraphicRaycaster>();
        if (EventSystem.current == null)
        {
            var eventObject = new GameObject("EventSystem");
            eventObject.AddComponent<EventSystem>();
            eventObject.AddComponent<StandaloneInputModule>();
        }
        BuildHud();
        BuildPausePanel();
        BuildWinPanel();
    }

    private void BuildHud()
    {
        var header = Panel("Top Card", new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0, -28), new Vector2(960, 190), new Color(0.08f, 0.17f, 0.24f, 0.95f));
        header.transform.SetParent(canvas.transform, false);
        Text(header.transform, "COLORFLOW", 42, FontStyle.Bold, Color.white, new Vector2(0.5f, 0.76f), new Vector2(0.5f, 0.76f), new Vector2(0, 0), new Vector2(620, 64), TextAnchor.MiddleCenter);
        levelText = Text(header.transform, "LEVEL 1 • FIRST PICKUP", 27, FontStyle.Bold, new Color(0.98f, 0.77f, 0.38f), new Vector2(0.5f, 0.38f), new Vector2(0.5f, 0.38f), Vector2.zero, new Vector2(580, 54), TextAnchor.MiddleCenter);
        coinsText = Text(header.transform, "COINS 0", 23, FontStyle.Bold, new Color(0.74f, 0.9f, 0.87f), new Vector2(0.9f, 0.38f), new Vector2(0.9f, 0.38f), Vector2.zero, new Vector2(190, 54), TextAnchor.MiddleCenter);

        var objective = Panel("Passenger Card", new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0, -247), new Vector2(900, 112), new Color(1f, 1f, 1f, 0.94f));
        objective.transform.SetParent(canvas.transform, false);
        passengerSwatch = Image(objective.transform, "Passenger Color", new Vector2(0.06f, 0.5f), new Vector2(0.06f, 0.5f), new Vector2(0, 0), new Vector2(42, 42), new Color(0.95f, 0.4f, 0.32f));
        passengerText = Text(objective.transform, "NEXT PASSENGERS", 27, FontStyle.Bold, new Color(0.12f, 0.22f, 0.3f), new Vector2(0.55f, 0.6f), new Vector2(0.55f, 0.6f), Vector2.zero, new Vector2(700, 42), TextAnchor.MiddleCenter);
        movesText = Text(objective.transform, "MOVES 0", 21, FontStyle.Bold, new Color(0.34f, 0.47f, 0.54f), new Vector2(0.55f, 0.24f), new Vector2(0.55f, 0.24f), Vector2.zero, new Vector2(700, 34), TextAnchor.MiddleCenter);

        selectedText = Text(canvas.transform, "Tap a vehicle, then swipe along its lane", 24, FontStyle.Bold, Color.white, new Vector2(0.5f, 0.18f), new Vector2(0.5f, 0.18f), new Vector2(0, 0), new Vector2(1000, 62), TextAnchor.MiddleCenter);
        var footer = Panel("Controls", new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(0, 30), new Vector2(1020, 220), new Color(0.08f, 0.17f, 0.24f, 0.96f));
        footer.transform.SetParent(canvas.transform, false);
        MakeButton(footer.transform, "UNDO", new Vector2(0.13f, 0.5f), new Vector2(210, 112), new Color(0.19f, 0.43f, 0.51f), () => GameManager.Instance?.Undo());
        MakeButton(footer.transform, "HINT", new Vector2(0.38f, 0.5f), new Vector2(210, 112), new Color(0.92f, 0.66f, 0.26f), () => GameManager.Instance?.RequestHint());
        MakeButton(footer.transform, "RESTART", new Vector2(0.63f, 0.5f), new Vector2(210, 112), new Color(0.83f, 0.39f, 0.34f), () => GameManager.Instance?.RestartLevel());
        MakeButton(footer.transform, "PAUSE", new Vector2(0.88f, 0.5f), new Vector2(170, 112), new Color(0.29f, 0.55f, 0.42f), () => GameManager.Instance?.TogglePause());
        toastText = Text(canvas.transform, "", 25, FontStyle.Bold, Color.white, new Vector2(0.5f, 0.69f), new Vector2(0.5f, 0.69f), Vector2.zero, new Vector2(920, 100), TextAnchor.MiddleCenter);
    }

    private void BuildPausePanel()
    {
        pausePanel = Overlay("PAUSED", new Color(0.05f, 0.1f, 0.15f, 0.85f));
        MakeButton(pausePanel.transform, "RESUME", new Vector2(0.5f, 0.44f), new Vector2(430, 112), new Color(0.21f, 0.57f, 0.46f), () => GameManager.Instance?.TogglePause());
        soundToggleText = MakeButton(pausePanel.transform, "SOUND: ON", new Vector2(0.5f, 0.31f), new Vector2(430, 90), new Color(0.2f, 0.38f, 0.5f), ToggleSound);
        hapticsToggleText = MakeButton(pausePanel.transform, "VIBRATION: ON", new Vector2(0.5f, 0.2f), new Vector2(430, 90), new Color(0.2f, 0.38f, 0.5f), ToggleHaptics);
        pausePanel.SetActive(false);
    }

    private void BuildWinPanel()
    {
        winPanel = Overlay("PICKUP COMPLETE!", new Color(0.05f, 0.12f, 0.16f, 0.88f));
        Text(winPanel.transform, "EVERYONE'S ON BOARD", 27, FontStyle.Bold, new Color(0.76f, 0.9f, 0.87f), new Vector2(0.5f, 0.56f), new Vector2(0.5f, 0.56f), Vector2.zero, new Vector2(740, 58), TextAnchor.MiddleCenter);
        MakeButton(winPanel.transform, "PLAY AGAIN", new Vector2(0.5f, 0.39f), new Vector2(430, 112), new Color(0.92f, 0.66f, 0.26f), () => GameManager.Instance?.RestartLevel());
        winPanel.SetActive(false);
    }

    public void Refresh(GameManager game)
    {
        if (game == null || levelText == null) return;
        levelText.text = $"LEVEL {game.CurrentLevel} • FIRST PICKUP";
        movesText.text = $"MOVES {game.Moves}";
        coinsText.text = $"COINS {SaveSystem.Coins}";
        if (game.Passengers != null)
        {
            passengerText.text = game.Passengers.TotalRemaining > 0 ? game.Passengers.StatusText().ToUpperInvariant() : "ALL PASSENGERS ABOARD!";
            passengerSwatch.color = game.Passengers.NextColor;
        }
        var selected = game.SelectedVehicle;
        if (selected == null) selectedText.text = "Tap a vehicle, then swipe along its lane";
        else selectedText.text = selected.IsBus ? $"{selected.DisplayName}  •  {selected.Capacity} SEATS" : $"{selected.DisplayName}  •  SLIDES { (selected.Horizontal ? "LEFT / RIGHT" : "UP / DOWN") }";
        if (soundToggleText != null) soundToggleText.text = SaveSystem.SoundOn ? "SOUND: ON" : "SOUND: OFF";
        if (hapticsToggleText != null) hapticsToggleText.text = SaveSystem.HapticsOn ? "VIBRATION: ON" : "VIBRATION: OFF";
    }

    public void ShowMessage(string message)
    {
        if (toastText == null) return;
        toastText.text = message;
        CancelInvoke(nameof(ClearMessage));
        Invoke(nameof(ClearMessage), 3.5f);
    }

    private void ClearMessage() { if (toastText != null) toastText.text = ""; }
    public void SetPaused(bool paused) { if (pausePanel != null) pausePanel.SetActive(paused); }
    public void ShowCompletion(int reward) { if (winPanel != null) { winPanel.SetActive(true); ShowMessage($"LEVEL COMPLETE  •  +{reward} COINS"); } }
    public void HideCompletion() { if (winPanel != null) winPanel.SetActive(false); }

    private void ToggleSound()
    {
        SaveSystem.SetSound(!SaveSystem.SoundOn);
        Refresh(GameManager.Instance);
    }

    private void ToggleHaptics()
    {
        SaveSystem.SetHaptics(!SaveSystem.HapticsOn);
        Refresh(GameManager.Instance);
    }

    private GameObject Overlay(string title, Color color)
    {
        var overlay = Panel(title + " Overlay", new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(1080, 1920), color);
        overlay.transform.SetParent(canvas.transform, false);
        Text(overlay.transform, title, 52, FontStyle.Bold, Color.white, new Vector2(0.5f, 0.62f), new Vector2(0.5f, 0.62f), Vector2.zero, new Vector2(900, 100), TextAnchor.MiddleCenter);
        return overlay;
    }

    private static GameObject Panel(string name, Vector2 anchorMin, Vector2 anchorMax, Vector2 position, Vector2 size, Color color)
    {
        var go = new GameObject(name, typeof(RectTransform), typeof(Image));
        var rect = go.GetComponent<RectTransform>();
        rect.anchorMin = anchorMin; rect.anchorMax = anchorMax; rect.anchoredPosition = position; rect.sizeDelta = size;
        go.GetComponent<Image>().color = color;
        return go;
    }

    private static Image Image(Transform parent, string name, Vector2 anchorMin, Vector2 anchorMax, Vector2 position, Vector2 size, Color color)
    {
        var go = new GameObject(name, typeof(RectTransform), typeof(Image));
        go.transform.SetParent(parent, false);
        var rect = go.GetComponent<RectTransform>();
        rect.anchorMin = anchorMin; rect.anchorMax = anchorMax; rect.anchoredPosition = position; rect.sizeDelta = size;
        var image = go.GetComponent<Image>(); image.color = color;
        return image;
    }

    private static Text Text(Transform parent, string value, int size, FontStyle style, Color color, Vector2 anchorMin, Vector2 anchorMax, Vector2 position, Vector2 rectSize, TextAnchor alignment)
    {
        var go = new GameObject("Text", typeof(RectTransform), typeof(Text));
        go.transform.SetParent(parent, false);
        var rect = go.GetComponent<RectTransform>();
        rect.anchorMin = anchorMin; rect.anchorMax = anchorMax; rect.anchoredPosition = position; rect.sizeDelta = rectSize;
        var text = go.GetComponent<Text>();
        text.text = value; text.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
        text.fontSize = size; text.fontStyle = style; text.color = color; text.alignment = alignment;
        text.horizontalOverflow = HorizontalWrapMode.Wrap; text.verticalOverflow = VerticalWrapMode.Overflow;
        text.raycastTarget = false;
        return text;
    }

    private static Text MakeButton(Transform parent, string label, Vector2 anchor, Vector2 size, Color color, UnityAction callback)
    {
        var go = new GameObject(label + " Button", typeof(RectTransform), typeof(Image), typeof(Button));
        go.transform.SetParent(parent, false);
        var rect = go.GetComponent<RectTransform>(); rect.anchorMin = anchor; rect.anchorMax = anchor; rect.anchoredPosition = Vector2.zero; rect.sizeDelta = size;
        var image = go.GetComponent<Image>(); image.color = color;
        var button = go.GetComponent<Button>(); button.targetGraphic = image; button.onClick.AddListener(callback);
        var text = Text(go.transform, label, 27, FontStyle.Bold, Color.white, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero, TextAnchor.MiddleCenter);
        text.rectTransform.offsetMin = new Vector2(12, 8); text.rectTransform.offsetMax = new Vector2(-12, -8);
        return text;
    }
}
