using UnityEngine;

public class AudioManager : MonoBehaviour
{
    private AudioSource source;
    private AudioClip clickClip;

    private void Awake()
    {
        source = gameObject.AddComponent<AudioSource>();
        source.playOnAwake = false;
        clickClip = MakeTone("Soft click", 660f, 0.055f);
    }

    public void PlayMove()
    {
        if (SaveSystem.SoundOn && source != null) source.PlayOneShot(clickClip, 0.18f);
        if (SaveSystem.HapticsOn && Application.isMobilePlatform) Handheld.Vibrate();
    }

    public void PlayWin()
    {
        if (SaveSystem.SoundOn && source != null) source.PlayOneShot(MakeTone("Chime", 880f, 0.22f), 0.22f);
        if (SaveSystem.HapticsOn && Application.isMobilePlatform) Handheld.Vibrate();
    }

    private static AudioClip MakeTone(string name, float frequency, float duration)
    {
        const int sampleRate = 22050;
        int count = Mathf.CeilToInt(sampleRate * duration);
        var samples = new float[count];
        for (int i = 0; i < count; i++)
        {
            float envelope = Mathf.Clamp01(1f - i / (float)count);
            samples[i] = Mathf.Sin(2f * Mathf.PI * frequency * i / sampleRate) * envelope * 0.35f;
        }
        var clip = AudioClip.Create(name, count, 1, sampleRate, false);
        clip.SetData(samples, 0);
        return clip;
    }
}
