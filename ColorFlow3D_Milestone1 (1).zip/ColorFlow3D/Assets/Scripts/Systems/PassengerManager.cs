using System;
using System.Collections.Generic;
using UnityEngine;

public class PassengerManager
{
    private readonly List<PassengerGroup> groups;
    private readonly int[] remaining;
    public int TotalRemaining { get; private set; }
    public string NextLabel { get; private set; }
    public Color NextColor { get; private set; }
    public event Action Changed;

    public PassengerManager(PassengerGroup[] definitions)
    {
        groups = new List<PassengerGroup>(definitions ?? Array.Empty<PassengerGroup>());
        remaining = new int[groups.Count];
        TotalRemaining = 0;
        for (int i = 0; i < groups.Count; i++)
        {
            remaining[i] = groups[i].count;
            TotalRemaining += remaining[i];
        }
        RefreshNext();
    }

    public bool CanBoard(VehicleController vehicle)
    {
        if (TotalRemaining <= 0 || vehicle == null || !vehicle.IsBus) return false;
        int next = NextNonEmptyGroup();
        if (next < 0) return false;
        ColorUtility.TryParseHtmlString(groups[next].color, out var color);
        return ColorsMatch(color, vehicle.VehicleColor) && vehicle.Capacity > 0;
    }

    public bool TryBoard(VehicleController vehicle)
    {
        if (!CanBoard(vehicle)) return false;
        int next = NextNonEmptyGroup();
        int boarded = Mathf.Min(vehicle.Capacity, remaining[next]);
        remaining[next] -= boarded;
        TotalRemaining -= boarded;
        RefreshNext();
        Changed?.Invoke();
        return true;
    }

    public int[] Capture() => (int[])remaining.Clone();

    public void Restore(int[] snapshot)
    {
        if (snapshot == null || snapshot.Length != remaining.Length) return;
        TotalRemaining = 0;
        for (int i = 0; i < remaining.Length; i++)
        {
            remaining[i] = Mathf.Max(0, snapshot[i]);
            TotalRemaining += remaining[i];
        }
        RefreshNext();
        Changed?.Invoke();
    }

    public string StatusText()
    {
        if (TotalRemaining == 0) return "All passengers are aboard!";
        return $"Next: {NextLabel} × {TotalRemainingForNext()}";
    }

    private int TotalRemainingForNext()
    {
        int index = NextNonEmptyGroup();
        return index < 0 ? 0 : remaining[index];
    }

    private int NextNonEmptyGroup()
    {
        for (int i = 0; i < remaining.Length; i++) if (remaining[i] > 0) return i;
        return -1;
    }

    private void RefreshNext()
    {
        int index = NextNonEmptyGroup();
        if (index < 0) { NextLabel = "None"; NextColor = Color.white; return; }
        NextLabel = string.IsNullOrWhiteSpace(groups[index].label) ? "Passengers" : groups[index].label;
        if (!ColorUtility.TryParseHtmlString(groups[index].color, out NextColor)) NextColor = Color.white;
    }

    private static bool ColorsMatch(Color a, Color b)
    {
        return Mathf.Abs(a.r - b.r) < 0.03f && Mathf.Abs(a.g - b.g) < 0.03f && Mathf.Abs(a.b - b.b) < 0.03f;
    }
}
