using UnityEngine;

public static class SaveSystem
{
    private const string LevelKey = "colorflow_unlocked_level";
    private const string CoinKey = "colorflow_coins";
    private const string SoundKey = "colorflow_sound_on";
    private const string HapticsKey = "colorflow_haptics_on";
    public static int UnlockedLevel => Mathf.Max(1, PlayerPrefs.GetInt(LevelKey, 1));
    public static int Coins => Mathf.Max(0, PlayerPrefs.GetInt(CoinKey, 0));
    public static bool SoundOn => PlayerPrefs.GetInt(SoundKey, 1) != 0;
    public static bool HapticsOn => PlayerPrefs.GetInt(HapticsKey, 1) != 0;
    public static void Unlock(int level) { PlayerPrefs.SetInt(LevelKey, Mathf.Max(UnlockedLevel, level)); PlayerPrefs.Save(); }
    public static void AddCoins(int amount) { PlayerPrefs.SetInt(CoinKey, Coins + Mathf.Max(0, amount)); PlayerPrefs.Save(); }
    public static void SetSound(bool enabled) { PlayerPrefs.SetInt(SoundKey, enabled ? 1 : 0); PlayerPrefs.Save(); }
    public static void SetHaptics(bool enabled) { PlayerPrefs.SetInt(HapticsKey, enabled ? 1 : 0); PlayerPrefs.Save(); }
}

public static class ProgressionManager
{
    public static int CompletionReward => 25;
    public static void CompleteLevel(int currentLevel)
    {
        SaveSystem.AddCoins(CompletionReward);
        SaveSystem.Unlock(currentLevel + 1);
    }
}
