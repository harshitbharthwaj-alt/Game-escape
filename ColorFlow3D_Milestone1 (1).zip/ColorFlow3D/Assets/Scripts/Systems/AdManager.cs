using UnityEngine;

/// <summary>Ad integration intentionally stays inactive until a real AdMob SDK and consent flow are configured.</summary>
public class AdManager : MonoBehaviour
{
    public bool IsConfigured => false;

    public void RequestRewardedHint(System.Action<bool> onRewarded)
    {
        Debug.Log("AdMob is not configured in this prototype; no ad was shown and no reward was granted.");
        onRewarded?.Invoke(false);
    }

    public void RequestInterstitial() { }
}
