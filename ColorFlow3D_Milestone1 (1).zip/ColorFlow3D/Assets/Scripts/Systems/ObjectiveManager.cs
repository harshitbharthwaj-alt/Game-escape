using System;

public class ObjectiveManager
{
    public bool IsComplete { get; private set; }
    public event Action Completed;

    public void Evaluate(PassengerManager passengers)
    {
        if (IsComplete || passengers == null || passengers.TotalRemaining > 0) return;
        IsComplete = true;
        Completed?.Invoke();
    }

    public void Reset() => IsComplete = false;
}
