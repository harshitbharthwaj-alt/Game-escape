using NUnit.Framework;
using UnityEngine;

public class LevelValidatorTests
{
    [Test]
    public void FirstLevelResourceLoadsAndPassesStructuralValidation()
    {
        TextAsset asset = Resources.Load<TextAsset>("Levels/level_01");
        Assert.That(asset, Is.Not.Null, "The first level JSON must be included as a Resources TextAsset.");
        LevelData level = JsonUtility.FromJson<LevelData>(asset.text);
        Assert.That(level, Is.Not.Null);
        Assert.That(LevelValidator.Validate(level), Is.Empty);
    }

    [Test]
    public void FirstLevelHasAColorMatchedBusAndPassengerDemand()
    {
        TextAsset asset = Resources.Load<TextAsset>("Levels/level_01");
        Assert.That(asset, Is.Not.Null);
        LevelData level = JsonUtility.FromJson<LevelData>(asset.text);
        bool hasCapacityBus = false;
        foreach (var vehicle in level.vehicles) hasCapacityBus |= vehicle.isBus && vehicle.capacity >= 2;
        bool hasPassengerDemand = false;
        foreach (var group in level.passengers) hasPassengerDemand |= group.count == 2 && group.color == "#F37463";
        Assert.That(hasCapacityBus, Is.True);
        Assert.That(hasPassengerDemand, Is.True);
    }
}
