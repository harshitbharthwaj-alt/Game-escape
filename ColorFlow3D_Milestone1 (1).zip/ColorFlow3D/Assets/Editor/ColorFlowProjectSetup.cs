using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class ColorFlowProjectSetup
{
    private const string ScenePath = "Assets/Scenes/Main.unity";

    [MenuItem("ColorFlow/Setup/Create Main Scene & Android Settings")]
    public static void CreateSceneAndConfigure()
    {
        if (!AssetDatabase.IsValidFolder("Assets/Scenes")) AssetDatabase.CreateFolder("Assets", "Scenes");
        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        var bootstrap = new GameObject("ColorFlow Bootstrap");
        bootstrap.AddComponent<GameBootstrap>();
        EditorSceneManager.SaveScene(scene, ScenePath);
        EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };

        PlayerSettings.companyName = "Colorflow Studio";
        PlayerSettings.productName = "ColorFlow 3D: Bus Jam Escape";
        PlayerSettings.SetApplicationIdentifier(BuildTargetGroup.Android, "com.colorflow.busjamescape");
        PlayerSettings.defaultInterfaceOrientation = UIOrientation.Portrait;
        PlayerSettings.defaultScreenWidth = 1080;
        PlayerSettings.defaultScreenHeight = 1920;
        PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel23;
        PlayerSettings.Android.targetSdkVersion = AndroidSdkVersions.AndroidApiLevel36;
        PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
        PlayerSettings.Android.forceInternetPermission = false;
        AssetDatabase.SaveAssets();
        Debug.Log("ColorFlow main scene created and Android portrait / ARM64 / API 36 settings applied. Select Android in Build Profiles when its module is installed.");
        EditorUtility.DisplayDialog("ColorFlow setup complete", "Main scene created. Press Play to run the prototype. For an APK, install Unity 6.3 LTS Android Build Support (SDK/NDK/OpenJDK) and select Android in Build Profiles.", "OK");
    }
}
