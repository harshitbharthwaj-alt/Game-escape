#!/usr/bin/env python3
"""Small dependency-free validator/solver for ColorFlow Rush-Hour-style level JSON."""
import json
import sys
from collections import deque
from pathlib import Path


def solve(level, max_states=100_000):
    vehicles = level["vehicles"]
    sizes = [(v["length"], v["horizontal"]) for v in vehicles]
    starts = tuple((v["x"], v["z"]) for v in vehicles)
    active = tuple(True for _ in vehicles)
    passenger_counts = tuple(p["count"] for p in level["passengers"])
    start = (starts, active, passenger_counts)
    parents = {start: None}
    queue = deque([start])

    def cells(i, anchor):
        x, z = anchor
        length, horizontal = sizes[i]
        return [(x + k, z) if horizontal else (x, z + k) for k in range(length)]

    def occupant(positions, active_bits, cell, ignore):
        for j, pos in enumerate(positions):
            if j != ignore and active_bits[j] and cell in cells(j, pos):
                return j
        return None

    while queue and len(parents) < max_states:
        state = queue.popleft()
        positions, active_bits, remaining = state
        if sum(remaining) == 0:
            path = []
            cursor = state
            while parents[cursor] is not None:
                prev, action = parents[cursor]
                path.append(action)
                cursor = prev
            return list(reversed(path)), len(parents)

        for i, vehicle in enumerate(vehicles):
            if not active_bits[i]:
                continue
            x, z = positions[i]
            length, horizontal = sizes[i]
            for direction in (-1, 1):
                nx = x + (direction if horizontal else 0)
                nz = z + (0 if horizontal else direction)
                next_cells = cells(i, (nx, nz))
                off_right = horizontal and direction > 0 and nx + length > level["columns"]
                new_positions = list(positions)
                new_active = list(active_bits)
                new_remaining = list(remaining)
                if off_right:
                    if not vehicle["isBus"] or z != level["exitRow"] or nx != level["columns"] - length + 1:
                        continue
                    if any(0 <= cx < level["columns"] and occupant(positions, active_bits, (cx, cz), i) is not None for cx, cz in next_cells):
                        continue
                    group = next((g for g, count in enumerate(new_remaining) if count > 0), None)
                    if group is None or vehicle["color"].lower() != level["passengers"][group]["color"].lower():
                        continue
                    new_remaining[group] = max(0, new_remaining[group] - vehicle["capacity"])
                    new_active[i] = False
                    label = f"exit {vehicle['displayName']}"
                else:
                    if any(not (0 <= cx < level["columns"] and 0 <= cz < level["rows"]) or occupant(positions, active_bits, (cx, cz), i) is not None for cx, cz in next_cells):
                        continue
                    new_positions[i] = (nx, nz)
                    label = f"move {vehicle['displayName']} {'right' if horizontal and direction > 0 else 'left' if horizontal else 'up' if direction > 0 else 'down'} 1"
                candidate = (tuple(new_positions), tuple(new_active), tuple(new_remaining))
                if candidate not in parents:
                    parents[candidate] = (state, label)
                    queue.append(candidate)
    return None, len(parents)


def validate(path):
    level = json.loads(Path(path).read_text())
    errors = []
    cols, rows = level["columns"], level["rows"]
    occupied = {}
    for v in level["vehicles"]:
        for x, z in ([(v["x"] + k, v["z"]) for k in range(v["length"])] if v["horizontal"] else [(v["x"], v["z"] + k) for k in range(v["length"])]):
            if not (0 <= x < cols and 0 <= z < rows):
                errors.append(f"{v['id']} is outside the board at {(x, z)}")
            if (x, z) in occupied:
                errors.append(f"{v['id']} overlaps {occupied[(x, z)]} at {(x, z)}")
            occupied[(x, z)] = v["id"]
    if errors:
        raise SystemExit("INVALID: " + "; ".join(errors))
    path, states = solve(level)
    if path is None:
        raise SystemExit(f"UNSOLVABLE: searched {states} states")
    print(f"VALID: {len(level['vehicles'])} vehicles, {len(occupied)} occupied cells; solvable in {len(path)} actions ({states} states searched).")
    for step, action in enumerate(path, 1):
        print(f"{step}. {action}")


if __name__ == "__main__":
    validate(sys.argv[1] if len(sys.argv) > 1 else "Assets/Resources/Levels/level_01.json")
